INSERT INTO media(media_name, media_genres, media_type) VALUES ('The Blacklist', '[2, 3, 6, 8, 10, 13]', 'Show');
INSERT INTO media(media_name, media_genres, media_type) VALUES ('House', '[4, 7, 10]', 'Show');
INSERT INTO media(media_name, media_genres, media_type) VALUES ('Avengers: Infinity War', '[1, 5, 9, 15]', 'Movie');
INSERT INTO media(media_name, media_genres, media_type) VALUES ('Minecraft: The Movie', '[1, 4, 7, 12]', 'Movie');
INSERT INTO media_info(media_id, media_info_description, media_info_synopsis, media_info_season) values ('media-000000000001','template','template',1);
INSERT INTO media_info(media_id, media_info_description, media_info_synopsis, media_info_season) values ('media-000000000001','template','template',2);
INSERT INTO media_info(media_id, media_info_description, media_info_synopsis) values ('media-000000000003','template','template');
INSERT INTO media_info(media_id, media_info_description, media_info_synopsis) values ('media-000000000004','template','template');